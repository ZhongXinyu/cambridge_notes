#include <iostream>
#include <cmath>

double dy(double y, double t)
{
  return sqrt(y);
}

int main()
{
  double finalT, dt, y0;

  std::cout << "Enter final time: ";
  std::cin >> finalT;
  std::cout << "Enter initial value of y: ";
  std::cin >> y0;
  std::cout << "Enter time-step: ";
  std::cin >> dt;

  double t = 0, y = y0;
  while( t < finalT )
  {
    if( t + dt > finalT )
    {
      dt = finalT - t;
    }
    
    double k1 = dy(y,t);
    double k2 = dy(y + k1*dt, t + dt);
    y += dt*(k1+k2)/2;
    t += dt;
  }
  
  std::cout << "y(" << finalT << ") = " << y << std::endl;
}
