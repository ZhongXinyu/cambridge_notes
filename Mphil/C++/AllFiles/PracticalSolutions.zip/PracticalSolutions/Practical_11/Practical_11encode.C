#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include <fstream>

int main(void)
{
  std::string file;
  std::cout << "Enter filename: ";
  std::cin >> file;
  
  std::ifstream myFile(file.c_str(), std::ifstream::in);
  std::string text;

  std::string passphrase = "@zaphodbelrxisngvyucfjkmqtw";

  while(myFile)
  {
    std::string line;
    std::getline(myFile, line);
    text += line;
  }
  
  std::vector<unsigned int> charCount(27,0);

  for(std::string::const_iterator charIt = text.begin() ; charIt != text.end() ; ++charIt )
  {
    if( *charIt > 96 && *charIt <= 122)
    {
      std::cout << passphrase[(*charIt)-96];
    }
    else if( *charIt > 64 && *charIt <= 90)
    {
      std::cout << passphrase[(*charIt)-64];
    }
    else
    {
      std::cout << *charIt;
    }
  }
  
}
