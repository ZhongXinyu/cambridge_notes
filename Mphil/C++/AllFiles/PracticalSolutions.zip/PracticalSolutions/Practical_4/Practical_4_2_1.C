#include <iostream>

void partialSum(const int a[20], int sums[20])
{
  int sum = 0;
  for(int i=0 ; i < 20 ; i++)
  {
    sum += a[i];
    sums[i] = sum;
  }
  
}


int main(void)
{
}
