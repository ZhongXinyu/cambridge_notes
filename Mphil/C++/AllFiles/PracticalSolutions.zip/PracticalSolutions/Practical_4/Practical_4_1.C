#include <iostream>
#include <cmath>
#include <limits>

int sum(int a, int b)
{
  return a + b;
}

void decrease(int& a, int b)
{
  a -= b;
}

int q(int a, int b, int c, int& x1, int& x2)
{
  if( fabs(a) < 1e-8 )
  {
    if( fabs(b) < 1e-8 )
    {
      if( c != 0 )
      {
	return 0;
      }
      else
      {
	return std::numeric_limits<int>::max();
      }
    }
    else
    {
      x1 = -c / b;
      return 1;
    }
    
  }
  else
  {
    const double det = b*b - 4*a*c;
    if( det < 0 )
    {
      return 0;
    }
    else if( det > 0 )
    {
      x1 = (-b + sqrt(det)) / (2*a);
      x2 = (-b - sqrt(det)) / (2*a);
      return 2;
    }
    else
    {
      x1 = -b / (2*a);
      return 1;
    }
  }

}


int main(void)
{
}
