#include <iostream>



double det(const double m[3][3])
{
  double d = 0;

  d += m[0][0] * (m[1][1] * m[2][2] - m[1][2]*m[2][1]);
  d -= m[0][1] * (m[1][0] * m[2][2] - m[1][2]*m[2][0]);
  d += m[0][2] * (m[1][0] * m[2][1] - m[1][1]*m[2][0]);

  return d;
}

double trace(const double m[3][3])
{
  return m[0][0] + m[1][1] + m[2][2];
}

int main()
{
  double m[3][3];

  for(int i=0 ; i < 3 ; i++)
  {
    for(int j=0 ; j < 3 ; j++)
    {
      std::cout << "Enter m(" << i << "," << j << "): ";
      std::cin >> m[i][j];
    }
  }
  
  std::cout << "Trace = " << trace(m) << std::endl;
  std::cout << "Determinant = " << det(m) << std::endl;
}
