#include <iostream>

void calcNextRow(const int* prevRow, int* nextRow, int rowNo)
{
  nextRow[0] = 1;
  for(int i=1 ; i < rowNo ; i++)
  {
    nextRow[i] = prevRow[i] + prevRow[i-1];
  }
}


int main(void)
{
  int N;
  std::cout << "Enter number of rows required " << std::endl;
  std::cin >> N;

  int* row1 = new int[N];
  int* row2 = new int[N];

  row1[0] = 1;

  for(int i=0 ; i < N ; i++)
  {
    calcNextRow(row1, row2, i);
    for(int j=0 ; j < i-1 ; j++)
    {
      std::cout << row1[j] << " ";
    }
    std::cout << std::endl;

    int* tmp = row1;
    row1 = row2;
    row2 = tmp;
  }
}
